package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.Scanner;

public class Client {

    private static final String POST_URL = "http://localhost:8080/new";
    private static final String DELETE_URL = "http://localhost:8080/end";
    private static final String GET_URL = "http://localhost:8080/state";
    private static final String PUT_URL = "http://localhost:8080/move";

    public static void main(String[] args) {
        gameCycle();
    }

    public static String getClientChoice() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Tic Tac Toe!");
        System.out.println("Choose your player: 'X'/'O' - ");
        String choice = scanner.nextLine().toUpperCase();
        while (!choice.equals("X") && !choice.equals("O")) {
            System.out.println("Please choose either 'X' or 'O'");
            choice = scanner.nextLine().toUpperCase();
        }
        return choice;
    }


    public static void gameCycle() {
        try {
            boolean gameOver = false;
            boolean newRound = true;
            Scanner scanner = new Scanner(System.in);

            while (!gameOver) {
                if (newRound) {
                    String clientChoice = getClientChoice();
                    newGame(clientChoice);
                    newRound = false;
                }
                String[] menuOptions = {"1", "2", "3"};
                System.out.println("Choose your action(1, 2, 3):");
                System.out.println("1 - Make a move");
                System.out.println("2 - Get the state of the game");
                System.out.println("3 - End game");
                String choice = scanner.nextLine();
                while (!Arrays.asList(menuOptions).contains(choice)) {
                    System.out.println("Please choose an action between 1-3");
                    choice = scanner.nextLine();
                }

                if (choice.equals("1")) {
                    String row;
                    String col;
                    do {
                        System.out.println("Please enter your row number (1-3): ");
                        row = scanner.nextLine();
                        System.out.println("Please enter your column number (1-3): ");
                        col = scanner.nextLine();

                    } while (!Arrays.asList(menuOptions).contains(row) || !Arrays.asList(menuOptions).contains(col));
                    makeMove(Integer.parseInt(row) - 1,Integer.parseInt(col) - 1);

                } else if (choice.equals("2")) {
                    getState();

                } else {
                    boolean flag = false;
                    do {
                        System.out.println("Would you like to play again?");
                        System.out.println("Enter 1 for YES");
                        System.out.println("Enter 2 for NO");
                        choice = scanner.nextLine();
                        switch (choice) {
                            case "1":
                                flag = true;
                                newRound = true;
                                break;

                            case "2":
                                gameOver = true;
                                flag = true;
                                break;

                            default:
                                System.out.println("Please answer by pressing 1 or 2");
                                break;
                        }
                    } while (!flag);
                }
            }
            endGame();
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }


    public static void newGame(String clientChoice) throws IOException {
        URL url = new URL(POST_URL);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);

        try (OutputStream os = connection.getOutputStream()) {
            os.write(("player=" + clientChoice).getBytes());
            os.flush();
        }

        int responseCode = connection.getResponseCode();
        String responseMsg = connection.getResponseMessage();
        String errorResponse = "POST Response Code :: " + responseCode +"\nPost Response Message :: " + responseMsg;

        if (responseCode == HttpURLConnection.HTTP_OK) {
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            System.out.println(response);
        } else {
            System.out.println("POST request did not work");
            System.out.println(errorResponse);
        }
    }


    public static void endGame() throws IOException {
        URL url = new URL(DELETE_URL);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("DELETE");

        int responseCode = connection.getResponseCode();
        String responseMsg = connection.getResponseMessage();
        String errorResponse = "DELETE Response Code :: " + responseCode +"\nDELETE Response Message :: " + responseMsg;

        if (responseCode == HttpURLConnection.HTTP_OK) {
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            System.out.println(response);
        } else {
            System.out.println("DELETE request did not work");
            System.out.println(errorResponse);
        }
    }


    public static void getState() throws IOException {
        URL url = new URL(GET_URL);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        int responseCode = connection.getResponseCode();
        String responseMsg = connection.getResponseMessage();
        String errorResponse = "GET Response Code :: " + responseCode +"\nGET Response Message :: " + responseMsg;

        if (responseCode == HttpURLConnection.HTTP_OK) {
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append("\n" + inputLine);
            }
            in.close();

            System.out.println(response);
        } else {

            System.out.println("GET request did not work");
            System.out.println(errorResponse);
        }
    }


    public static void makeMove(int row, int col) throws IOException {
        URL url = new URL(PUT_URL);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("PUT");
        connection.setDoOutput(true);

        try (OutputStream os = connection.getOutputStream()) {
            String requestBody = "row=" + row + "&col=" + col;
            os.write(requestBody.getBytes());
            os.flush();
        }

        int responseCode = connection.getResponseCode();
        String responseMsg = connection.getResponseMessage();
        String errorResponse = "PUT Response Code :: " + responseCode +"\nPUT Response Message :: " + responseMsg;

        if (responseCode == HttpURLConnection.HTTP_OK) {
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            response.append("\n");
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine + "\n");
            }
            in.close();

            System.out.println(response);
        } else {

            System.out.println("PUT request did not work");
            System.out.println(errorResponse);
        }
    }
}
