package server;

import java.util.Arrays;
import java.util.Random;

public class Game {

    private String[][] board;
    private int[] rows = {0,0,0};
    private int[] cols = {0,0,0};
    private int mainDiag = 0;
    private int subDiag = 0;
    private String currentPlayer;
    private boolean gameOver;
    private String gameStateMessage;

    public Game (String clientChoice) {
        this.currentPlayer = "X";
        this.gameOver = false;
        this.gameStateMessage = "The state of the game is:";
        this.board = new String[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j] = "";
            }
        }
        if (clientChoice.equals("O")) {
            makeComputerMove();
        }
    }

    public String getGameStateMessage() {
        return gameStateMessage;
    }

    public int makeMove(int row, int col, boolean isComputer) {
        if (gameOver) {
            return 1;
        } else if (!board[row][col].equals("")) {
            return 2;
        }

        board[row][col] = currentPlayer;
        rows[row] += currentPlayer.equals("X") ? 1 : -1;
        cols[col] += currentPlayer.equals("X") ? 1 : -1;
        if (row == col) {
            mainDiag += currentPlayer.equals("X") ? 1 : -1;
        }
        if ((row == 0 && col == 2) || (row == 1 && col == 1) || (row == 2 && col == 0)) {
            subDiag += currentPlayer.equals("X") ? 1 : -1;
        }

        if (isWin(row,col)) {
            gameOver = true;
            gameStateMessage = currentPlayer + " is the winner!\nCongratulations!!!";
        }
        else if (isTie()) {
            gameOver = true;
            gameStateMessage = "The game ended in a tie!\nThanks for playing :)";
        }
        else {
            currentPlayer = currentPlayer.equals("X") ? "O" : "X";
        }
        if (!isComputer) {
            makeComputerMove();
        }
        return 0;
    }

    public void makeComputerMove() {
        int[] possibleMoves = new int[9];
        int currentIndex = 0;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j].equals("")) {
                    possibleMoves[currentIndex] = i * 10 + j;
                    currentIndex ++;
                }
            }
        }
        if (currentIndex != 0) {
            int move = new Random().nextInt(currentIndex);
            int row = possibleMoves[move] / 10;
            int col = possibleMoves[move] % 10;
            makeMove(row, col, true);
        }
        else {
            gameOver = true;
            makeMove(0, 0, true);
        }
    }

    public boolean isWin(int row, int col) {
        if (Math.abs(rows[row]) == 3 ||
                Math.abs(cols[col]) == 3 ||
                Math.abs(mainDiag) == 3 ||
                Math.abs(subDiag) == 3) {
            return true;
        }
        return false;
    }

    public boolean isTie() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j].equals("")) {
                    return false;
                }
            }
        }
        return true;
    }

    public String printBoard() {
        StringBuilder printBoard = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                printBoard.append(" ").append(board[i][j]).append(" ");
                if (j < 2) {
                    printBoard.append("|");
                }
            }
            printBoard.append("\n");

            if (i < 2) {
                printBoard.append("-----------\n");
            }
        }
        return printBoard.toString();
    }

    public String getState() {
        return printBoard();
    }
}
