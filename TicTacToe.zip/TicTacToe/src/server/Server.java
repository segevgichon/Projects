package server;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;


public class Server {

    private Game game;
    private SessionManager sessionManager;

    public static void main( String[] args ) throws Exception {
        Server serverInstance = new Server();
        serverInstance.sessionManager = new SessionManager();
        InetAddress localAddress = InetAddress.getByName("127.0.0.1");
        HttpServer server = HttpServer.create(new InetSocketAddress(localAddress, 8080), 0);
        server.createContext("/new", serverInstance.new NewGameHandler());
        server.createContext("/end", serverInstance.new EndGameHandler());
        server.createContext("/state", serverInstance.new GetStateHandler());
        server.createContext("/move", serverInstance.new MakeMoveHandler());
        server.start();
    }

    private static void sendResponse(HttpExchange exchange, int statusCode, Response response) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", "text/plain");
        exchange.sendResponseHeaders(statusCode, response.length());
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(response.getBytes());
            os.flush();
        }
    }

    private static Map<String,String> extractParametersFromRequestBody(HttpExchange exchange) {
        Map<String,String> parameters = new HashMap<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8))) {
            String line = reader.readLine();
            String[] pairs = line.split("&");
            for (String pair : pairs) {
                String[] keyValPair = pair.split("=");
                parameters.put(keyValPair[0], URLDecoder.decode(keyValPair[1], StandardCharsets.UTF_8));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return parameters;
    }

    public class NewGameHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (exchange.getRequestMethod().equals("POST")) {
                try {
                    // Extract form parameters from the request body
                    Map<String, String> parameters = extractParametersFromRequestBody(exchange);

                    // Validate and handle client choice
                    String clientChoice = parameters.get("player");
                    if (!("X".equals(clientChoice) || "O".equals(clientChoice))) {
                        sendResponse(exchange, 400, new Response("Invalid choice - X/O", ""));
                        return;
                    }

                    game = new Game(clientChoice);

                    String ipAddress = exchange.getRemoteAddress().getAddress().getHostAddress();
                    if (!sessionManager.isContains(ipAddress) || sessionManager.isValidSession(ipAddress)) {
                        sessionManager.startOrUpdateSession(ipAddress);
                    }
                    else {
                        sessionManager.removeSession(ipAddress);
                        sendResponse(exchange, 401, new Response("Session Timeout", ""));
                        exchange.close();
                    }

                    sendResponse(exchange, 200, new Response("New game started", ""));

                } catch (Exception e) {
                    sendResponse(exchange, 400, new Response("Bad Request", ""));
                }

            } else {
                sendResponse(exchange, 405, new Response("Method Not Allowed", ""));
            }
        }
    }

    public class EndGameHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (exchange.getRequestMethod().equals("DELETE")) {
                try {
                    String ipAddress = exchange.getRemoteAddress().getAddress().getHostAddress();
                    if (!sessionManager.isValidSession(ipAddress)) {
                        sessionManager.removeSession(ipAddress);
                        sendResponse(exchange, 401, new Response("Session Timeout", ""));
                        exchange.close();
                    }
                    else {
                        sessionManager.removeSession(ipAddress);
                    }

                    if (game == null) {
                        sendResponse(exchange, 400, new Response("No Active Game", ""));
                        return;
                    }
                    game = null;

                    sendResponse(exchange, 200, new Response("The game has ended! Thanks for playing :)", ""));
                    exchange.close();

                } catch (Exception e) {
                    sendResponse(exchange, 500, new Response("Internal Server Error: " + e.getMessage(), ""));
                }

            } else {
                sendResponse(exchange, 405, new Response("Method Not Allowed", ""));
            }
        }
    }

    public class GetStateHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (exchange.getRequestMethod().equals("GET")) {
                try {
                    String ipAddress = exchange.getRemoteAddress().getAddress().getHostAddress();
                    if (sessionManager.isValidSession(ipAddress)) {
                        sessionManager.startOrUpdateSession(ipAddress);
                    }
                    else {
                        sessionManager.removeSession(ipAddress);
                        sendResponse(exchange, 401, new Response("Session Timeout", ""));
                        exchange.close();
                        return;
                    }

                    if (game == null) {
                        sendResponse(exchange, 400, new Response("No Active Game", ""));
                        return;
                    }

                    // Send the game state in the response
                    sendResponse(exchange, 200, new Response(game.getGameStateMessage() + "\n\n", game.getState()));


                } catch (Exception e) {
                    sendResponse(exchange, 500, new Response("Internal Server Error: " + e.getMessage(), ""));
                }

            } else {
                sendResponse(exchange, 405, new Response("Method Not Allowed", ""));
            }
        }
    }

    public class MakeMoveHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (exchange.getRequestMethod().equals("PUT")) {
                try {
                    String ipAddress = exchange.getRemoteAddress().getAddress().getHostAddress();
                    if (sessionManager.isValidSession(ipAddress)) {
                        sessionManager.startOrUpdateSession(ipAddress);
                    }
                    else {
                        sessionManager.removeSession(ipAddress);
                        sendResponse(exchange, 401, new Response("Session Timeout", ""));
                        exchange.close();
                        return;
                    }

                    if (game == null) {
                        sendResponse(exchange, 400, new Response("No Active Game", ""));
                        return;
                    }

                    Map<String, String> parameters = extractParametersFromRequestBody(exchange);
                    int row = Integer.parseInt(parameters.get("row"));
                    int col = Integer.parseInt(parameters.get("col"));
                    int isValidMove = game.makeMove(row,col,false);

                    // Send a success response
                    Response response;
                    if (isValidMove == 0) {
                        response = new Response(game.getGameStateMessage() + "\n\n", game.getState());
                    } else if (isValidMove == 1) {
                        response = new Response("Game is over\n", "");
                    } else { // == 2
                        response = new Response("Invalid move - square taken\n", "");
                    }
                    sendResponse(exchange, 200, response);


                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    sendResponse(exchange, 400, new Response(e.getMessage(), ""));
                } catch (Exception e) {
                    sendResponse(exchange, 500, new Response("Internal Server Error: " + e.getMessage(), ""));
                }

            } else {
                sendResponse(exchange, 405, new Response("Method Not Allowed", ""));

            }
        }
    }
}
