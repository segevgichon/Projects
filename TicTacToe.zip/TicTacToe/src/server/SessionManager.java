package server;

import java.util.HashMap;
import java.util.Map;

public class SessionManager {

    private static final long SESSION_TIMEOUT = 10 * 60 * 1000;

    private Map<String, Long> sessionStartTimes;

    public SessionManager() {
        this.sessionStartTimes = new HashMap<String, Long>();
    }

    public boolean isContains(String ipAddress) {
        return sessionStartTimes.containsKey(ipAddress);
    }

    public boolean isValidSession(String ipAddress) {
        long startTime = sessionStartTimes.get(ipAddress);
        long currentTime = System.currentTimeMillis();
        return currentTime - startTime <= SESSION_TIMEOUT;
    }

    public void startOrUpdateSession(String ipAddress) {
        sessionStartTimes.put(ipAddress, System.currentTimeMillis());
    }

    public void removeSession(String ipAddress) {
        sessionStartTimes.remove(ipAddress);
    }

}
