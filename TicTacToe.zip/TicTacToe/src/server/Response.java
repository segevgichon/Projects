package server;

import java.nio.charset.StandardCharsets;

public class Response {
    private final String message;
    private final String data;

    public Response(String message, String data) {
        this.message = message;
        this.data = data;
    }

    public int length() {
        return (this.message + this.data).getBytes(StandardCharsets.UTF_8).length;
    }

    public byte[] getBytes() {
        return (this.message + this.data).getBytes(StandardCharsets.UTF_8);
    }
}