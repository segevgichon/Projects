I have created 2 packages: server and client.

In the server packages there are 4 files,
Server (MAIN) - handles all of the http requests
SesssionManager - class to deal with timeouts
Game - class in charge of game logic
Response - class in charge of the format of the response 

In the client package there is 1 file,
Client (MAIN) - handles all of the http requests from client side 
		as well as acts as a gui through the command line